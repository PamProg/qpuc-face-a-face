let dateDebut;

start4 = () => {
  dateDebut = new Date();
  const bg4 = document.getElementById("bg4");
  let bg4Height = 100;

  let dateBefore4 = new Date();
  const bg4Inter = setInterval(() => {
    bg4.setAttribute("style", "height: " + bg4Height + "%");
    bg4Height -= 1.365;

    if (bg4Height <= 0) {
      bg4.setAttribute("style", "height: 0%");
      document.getElementById("chiffre4").setAttribute("style", "color: gray;");

      this.start3();

      const dateAfter4 = new Date();
      console.log("Temps passé 4 : ", (dateAfter4 - dateBefore4) / 1000);
      clearInterval(bg4Inter);
    }
  }, 100);
};

start3 = () => {
  const bg3 = document.getElementById("bg3");
  let bg3Height = 100;

  const dateBefore3 = new Date();

  const bg3Inter = setInterval(() => {
    bg3.setAttribute("style", "height: " + bg3Height + "%");
    bg3Height -= 1.85;

    if (bg3Height <= 0) {
      bg3.setAttribute("style", "height: 0%");
      document.getElementById("chiffre3").setAttribute("style", "color: gray;");

      this.start2();

      const dateAfter3 = new Date();
      console.log("Temps passé 3 : ", (dateAfter3 - dateBefore3) / 1000);
      clearInterval(bg3Inter);
    }
  }, 100);
};

start2 = () => {
  const bg2 = document.getElementById("bg2");
  let bg2Height = 100;

  const dateBefore2 = new Date();

  const bg2Inter = setInterval(() => {
    bg2.setAttribute("style", "height: " + bg2Height + "%");
    bg2Height -= 2.75;

    if (bg2Height <= 0) {
      bg2.setAttribute("style", "height: 0%");
      document.getElementById("chiffre2").setAttribute("style", "color: gray;");

      this.start1();

      const dateAfter2 = new Date();
      console.log("Temps passé 2 : ", (dateAfter2 - dateBefore2) / 1000);
      clearInterval(bg2Inter);
    }
  }, 100);
};

start1 = () => {
  const bg1 = document.getElementById("bg1");
  let bg1Height = 100;

  const dateBefore1 = new Date();

  let bg1Inter = setInterval(() => {
    bg1.setAttribute("style", "height: " + bg1Height + "%");
    bg1Height -= 5.5;

    if (bg1Height <= 0) {
      bg1.setAttribute("style", "height: 0%");
      document.getElementById("chiffre1").setAttribute("style", "color: gray;");

      const dateAfter1 = new Date();
      console.log("Temps passé 1 : ", (dateAfter1 - dateBefore1) / 1000);
      clearInterval(bg1Inter);

      console.log("Temps final : ", new Date() - dateDebut);
    }
  }, 100);
};
